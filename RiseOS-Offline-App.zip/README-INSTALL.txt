# RiseOS — private installable app

## Publish it privately for your phone
1. Upload **all five files** in this folder to the same folder in your GitHub repository:
   `index.html`, `manifest.json`, `sw.js`, `icon-192.png`, and `icon-512.png`.
2. In GitHub, open **Settings → Pages**.
3. Under Build and deployment, choose **Deploy from a branch**, select your branch (usually `main`) and folder (`/root`), then Save.
4. Wait for GitHub Pages to publish. Open the HTTPS Pages URL on your Android phone in Chrome.
5. Load the page once while online and wait a few seconds for offline caching.
6. Tap **Install RiseOS** if it appears, or Chrome menu **⋮ → Install app** / **Add to Home screen**.
7. Open the installed RiseOS app once. Then test by turning on Airplane mode and reopening it.

## Important
- A PWA cannot be installed directly from a GitHub repository's file view. It must be served from HTTPS (GitHub Pages provides HTTPS).
- Offline use starts only after the first successful online visit and service-worker installation.
- Your tasks are stored in browser storage on this device. They are not synced to GitHub or another device. Use **Manage → Backup & data → Export JSON** regularly.
- Keep the five files together in the same published folder. If you change the app later, change `CACHE_VERSION` in `sw.js` so installed phones fetch the new version.
- This creates a private-use home-screen web app, not an APK or an App Store/Play Store package.
